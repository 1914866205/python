print(pow(1*1.01,356-3))

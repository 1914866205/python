#定义一个函数
def printHello(str):
    print(str)


str=input("请输入hello")
printHello(str)
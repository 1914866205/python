
nowE=80
for i in range(1,11):
    print("我在第%d年重%.2fkg，在月球为%.2fkg" %(i,nowE ,nowE*0.165))
    nowE+=0.5

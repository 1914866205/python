#a3.8tqdmBar.py
from tqdm import tqdm
from time import sleep
for i in tqdm(range(1,100)):
    sleep(0.01)